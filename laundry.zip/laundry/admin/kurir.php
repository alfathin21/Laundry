 <?php 
include "../database/koneksi.php";

$kurir = query("SELECT * FROM t_kurir");
  ?>

 <!DOCTYPE html>
 <html lang="en">

 <head>

     <meta charset="utf-8">
     <meta http-equiv="X-UA-Compatible" content="IE=edge">
     <meta name="viewport" content="width=device-width, initial-scale=1">
     <meta name="description" content="">
     <meta name="author" content="">

     <title>Data Kurir</title>

     <!-- Bootstrap Core CSS -->
     <link href="vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">

     <!-- MetisMenu CSS -->
     <link href="vendor/metisMenu/metisMenu.min.css" rel="stylesheet">

     <!-- DataTables CSS -->
     <link href="vendor/datatables-plugins/dataTables.bootstrap.css" rel="stylesheet">

     <!-- DataTables Responsive CSS -->
     <link href="vendor/datatables-responsive/dataTables.responsive.css" rel="stylesheet">

     <!-- Custom CSS -->
     <link href="dist/css/sb-admin-2.css" rel="stylesheet">

     <!-- Custom Fonts -->
     <link href="vendor/font-awesome/css/font-awesome.min.css" rel="stylesheet" type="text/css">

 </head>

 <body>

     <div id="wrapper">

         <!-- Navigation -->
         <!-- Navigation -->
         <nav class="navbar navbar-default navbar-static-top" role="navigation" style="margin-bottom: 0">
             <div class="navbar-header">
                 <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse">
                     <span class="sr-only">Toggle navigation</span>
                     <span class="icon-bar"></span>
                     <span class="icon-bar"></span>
                     <span class="icon-bar"></span>
                 </button>
                 <a class="navbar-brand" href="index.html">Aplikasi Laundry</a>
             </div>
             <!-- /.navbar-header -->

             <ul class="nav navbar-top-links navbar-right">

                 <!-- /.dropdown -->
                 <li class="dropdown">
                     <a class="dropdown-toggle" data-toggle="dropdown" href="#">
                         <i class="fa fa-user fa-fw"></i> <i class="fa fa-caret-down"></i>
                     </a>
                     <ul class="dropdown-menu dropdown-user">
                         <li><a href="profil.php"><i class="fa fa-user fa-fw"></i> Profile User</a>
                         </li>
                         <li><a href="ubah_password.php"><i class="fa fa-gear fa-fw"></i> Ubah Password</a>
                         </li>
                         <li class="divider"></li>
                         <li><a href="../logout.php"><i class="fa fa-sign-out fa-fw"></i> Logout</a>
                         </li>
                     </ul>
                 </li>
             </ul>

             <div class="navbar-default sidebar" role="navigation">
                 <div class="sidebar-nav navbar-collapse">
                     <ul class="nav" id="side-menu">

                         <li>
                             <a href="index.php"><i class="fa fa-dashboard fa-fw"></i> Dashboard</a>
                         </li>
                         <li>
                             <a href="#"><i class="fa fa-list-alt fa-fw"></i> Data<span class="fa arrow"></span></a>
                             <ul class="nav nav-second-level">
                              <li>
                                 <a href="konsumen.php">Konsumen</a>
                             </li>
                             <li>
                                 <a href="barang.php">Barang</a>
                             </li>
                             <li class="active">
                                 <a href="kurir.php">Kurir</a>
                             </li>
                         </ul>
                     </li>
                     <li>
                         <a href="#"><i class="fa fa fa-edit fa-fw "></i> Transaksi<span class="fa arrow"></span></a>
                         <ul class="nav nav-second-level">
                          <li>
                             <a href="penyerahan_barang.php">Penyerahan Barang</a>
                         </li>
                         <li>
                             <a href="pengiriman_barang.php">Pengiriman Barang</a>
                         </li>

                     </ul>
                 </li>
                 <li>
                     <a href="#"><i class="fa fa-eye fa-fw "></i> Jejak Transaksi<span class="fa arrow"></span></a>
                     <ul class="nav nav-second-level">
                      <li>
                         <a href="pemesanan.php">Pemesanan</a>
                     </li>
                     <li>
                         <a href="pengiriman.php">Pengiriman </a>
                     </li>

                 </ul>
             </li>
             <li>
                 <a href="#"><i class="fa fa-files-o fa-fw"></i> Laporan<span class="fa arrow"></span></a>
                 <ul class="nav nav-second-level">
                     <li>
                         <a href="lp_konsumen.php" target="_blank">Konsumen</a>
                     </li>
                     <li>
                         <a href="lp_data_barang.php" target="_blank">Data Barang</a>
                     </li>
                     <li>
                         <a href="lp_pemesanan.php" target="_blank">Pemesanan</a>
                     </li>
                     <li>
                         <a href="lp_pengiriman.php" target="_blank">Pengiriman</a>
                     </li>
                 </ul>
             </li>
         </ul>
     </div>
 </div>
 </nav>

         <div id="page-wrapper">
             <div class="row">
                 <div class="col-lg-12">
                     <h1 class="page-header text-center">Table Data Kurir</h1>
                 </div>
                 <div class="col-lg-2">
                   
                     <a data-target="#tambah" 
              id="tambah_kurir" role="button"
              data-toggle="modal">

                     <button class="btn btn-primary">
                        <i class="fa fa fa-plus fa-fw "></i> Tambah Data
                     </button>
                     </a>
                 </div>
                  <div class="col-lg-1" style="margin-left:-30px">
                   
                     <a href="lp_kurir.php" target="_blank">

                     <button class="btn btn-info">
                        <i class="fa fa fa-print fa-fw "></i> Cetak Data
                     </button>
                     </a>
                 </div>
             </div>
             <!-- /.row -->
       <br>
             <!-- /.row -->
             <div class="row">
                 <div class="col-lg-12">
                     <div class="panel panel-default">
                         <div class="panel-heading">
                             Data Kurir
                         </div>
                         <!-- /.panel-heading -->
                         <div class="panel-body">
                             <div class="table-responsive">
                                 <table class="table table-striped table-bordered table-hover" id="dataTables-example">
                                     <thead>
                                         <tr>
                                             <th>Nomor</th>
                                             <th>Foto</th>
                                             <th>Nama Lengkap</th>
                                             <th>Handphone</th>
                                             <th>Aksi</th>
                                         </tr>
                                     </thead>
                                     <tbody>
                                      <?php $i=1; ?>
                                      <?php foreach ($kurir as $key ) :?>
                                         <tr>
                                          <td><?= $i; ?></td>
                                             <td><?= $key['foto_kurir']; ?></td>
                                             <td><?= $key['nama_lengkap']; ?></td>
                                             <td><?= $key['hp']; ?></td>
                                             <td>
                                                  <a data-target="#edit" 
              id="edit_kurir" role="button"
              data-id_kurir = <?= $key['id_kurir']; ?>
              data-nama_lengkap = <?= $key['nama_lengkap']; ?>
              data-hp = <?= $key['hp']; ?>
              data-toggle="modal">

                     <button class="btn btn-info">
                        <i class="fa fa fa-edit fa-fw "></i> 
                     </button>
                     </a>
                                 <a href="config/hapus_kurir.php?id=<?= $key["id_kurir"]; ?>" onclick="return confirm('yakin data dihapus ? ');">

                     <button class="btn btn-danger">
                        <i class="fa fa fa-trash fa-fw "></i> 
                     </button>
                     </a>
                                 
                                             </td>
                                         </tr>
                                         <?php $i++; ?>
                                        <?php endforeach; ?>
                                     </tbody>
                                 </table>
                             </div>
                             <!-- /.table-responsive -->
                         </div>
                         <!-- /.panel-body -->
                     </div>
                     <!-- /.panel -->
                 </div>
                 <!-- /.col-lg-6 -->
                 
             </div>
         </div>
     </div>
     

     <!-- modal tambah -->
     <div class="modal fade" id="tambah" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h3 class="modal-title text-center">Tambah Data Kurir</h3>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <form id="tambah" action="" method="POST">
        <div class="modal-body" id="modal-tambah">
         <div class="form-group">
           <label for="foto">Foto Kurir</label>
           <input type="file" name="foto[1]" id="foto[1]">
         </div>
         <div class="form-group">
           <label for="nama">NAMA Lengkap</label>
           <input type="text" name="nama" id="nama" class="form-control">
         </div>
         <div class="form-group">
           <label for="hp_kurir">Nomor Handphone</label>
           <input type="number" name="hp_kurir" id="hp_kurir" class="form-control">
         </div>
       </div>
       <div class="modal-footer">
        <button type="submit" class="btn btn-primary" name="simpan">Simpan</button>
        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
      </div>
    </form>
  </div>
</div>
</div>
     <!-- akhir modal -->

     <!-- modal edit -->
  <div class="modal fade" id="edit" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h3 class="modal-title text-center">Edit Data Kurir</h3>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <form id="form" action="" method="POST">
        <div class="modal-body" id="modal-edit">
       <input type="hidden" name="id_kurir" id="id_kurir">
         <img src="2.jpg" class="img-thumbnail" width="120px">
         <div class="form-group">
           <label for="foto_kurir">Foto Kurir</label>
           <input type="file" name="foto[2]" id="foto[2]">
         </div>
         <div class="form-group">
           <label for="nama_lengkap">NAMA Lengkap</label>
           <input type="text" name="nama_lengkap" id="nama_lengkap" class="form-control">
         </div>
         <div class="form-group">
           <label for="hp">Nomor Handphone</label>
           <input type="number" name="hp" id="hp" class="form-control">
         </div>
       </div>
       <div class="modal-footer">
        <button type="submit" class="btn btn-primary" name="edit">Simpan</button>
        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
      </div>
    </form>
  </div>
</div>
</div>

 <!-- simpan data kurir -->

 <?php 

  

   if (isset($_POST['simpan'])) {
    $nama_lengkap = $_POST['nama'];
    $hp = $_POST['hp_kurir'];
    $foto_kurir = upload();


    $query = "INSERT INTO t_kurir VALUES ('','$foto_kurir','$nama_lengkap','$hp') ";

    mysqli_query($koneksi,$query);

   echo "<script>
  alert('Data kurir berhasil ditambahkan');
  document.location.href = 'kurir.php';
  </script>";

   }


  function upload(){
  $nama_file = $_FILES['foto']['name']['1'];
  $ukuran_file = $_FILES['foto']['size']['1'];
  $error = $_FILES['foto']['error']['1'];
  $tmpName = $_FILES['foto']['tmp_name']['1'];
// cek apakah tidak ada gambar yang di upload
  if ($error === 4){
   echo "
   <script>
   alert('Silahkan Pilih Foto kuri');
   </script>";
   return false;
  }
// cek apakah file yang di upload adalah gambar

  $ekstensiGambarValid = ['jpg','jpeg','png','JPG','JPEG','PNG'];
  $ekstensiGambar = explode('.', $nama_file);
  $ekstensiGambar = strtolower(end($ekstensiGambar));
  if( !in_array($ekstensiGambar, $ekstensiGambarValid)){
   return false;
  }

// cek jika ukuran file terlalu besar

  if ($ukuran_file > 7000000){
 echo "
 <script>
 alert('Maaf,Ukuran foto kurir lebih dari 7 mb, Silahkan pilih foto kurir yang beukuran kurang dari 7 mb');
 </script>";
 return false;
}


 // generate nama file ketika ada nama file foto yang sama

  $nama_fileBaru  = uniqid();
  $nama_fileBaru .= '.';
  $nama_fileBaru .= $ekstensiGambar;

 // file sudah lolos pengecekan dan siap untuk di upload 

  move_uploaded_file($tmpName,'foto/foto_kurir/' . $nama_fileBaru);

  return $nama_fileBaru;

 }
  ?>
 <!-- akhir simpan data kurir -->
     <script src="vendor/jquery/jquery.min.js"></script>
     <script src="vendor/bootstrap/js/bootstrap.min.js"></script>
     <script src="vendor/metisMenu/metisMenu.min.js"></script>
     <script src="vendor/datatables/js/jquery.dataTables.min.js"></script>
     <script src="vendor/datatables-plugins/dataTables.bootstrap.min.js"></script>
     <script src="vendor/datatables-responsive/dataTables.responsive.js"></script>
     <script src="dist/js/sb-admin-2.js"></script>
     <script>
     $(document).ready(function() {
         $('#dataTables-example').DataTable({
             responsive: true
         });
     });
     </script>
     <script type="text/javascript">
      
  $(document).on("click","#edit_kurir", function(){
    var id_kurir = $(this).data('id_kurir'); 
    var nama_lengkap = $(this).data('nama_lengkap');
    var hp = $(this).data('hp'); 

     $("#modal-edit #id_kurir").val(id_kurir); 
    $("#modal-edit #nama_lengkap").val(nama_lengkap);  
    $("#modal-edit #hp").val(hp); 

  })

  $(document).ready(function(e){
    $("#form").on("submit", (function(e) {
      e.preventDefault();
      $.ajax({
        url : 'config/ubah_kurir.php',
        type : 'POST',
        data : new FormData(this),
        contentType : false,
        cache : false,
        processData : false,
        success : function(msg){
          $('.table').html(msg);
        }
      });
    }));
  })
     </script>

 </body>

 </html>


