<?php
 require '../../database/koneksi.php';
if (isset($_GET["id"])) {
$id_konsumen = $_GET["id"];

$query = "DELETE FROM t_konsumen where id_konsumen = '$id_konsumen' ";

mysqli_query($koneksi,$query);

echo "
  <script>
  alert('Data Berhasil dihapus');

  window.location='../konsumen.php';
  </script>
  ";
}


?>