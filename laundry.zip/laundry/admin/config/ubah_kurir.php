<?php 
	include_once "../../database/koneksi.php";

global $koneksi;
$id_kurir = $_POST["id_kurir"];
$nama_lengkap = $_POST["nama_lengkap"];
$hp = $_POST["hp"];

$update = "UPDATE t_kurir SET nama_lengkap = '$nama_lengkap', hp = '$hp' WHERE id_kurir='$id_kurir' ";

mysqli_query($koneksi,$update);

	echo "
	<script>
	alert('Data bagian, berhasil di update!');
	window.location='../admin/kurir.php';
	</script>

	";
		
 ?>