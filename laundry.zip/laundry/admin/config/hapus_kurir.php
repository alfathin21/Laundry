<?php
 require '../../database/koneksi.php';
if (isset($_GET["id"])) {
$id_kurir = $_GET["id"];

$query = "DELETE FROM t_kurir where id_kurir = '$id_kurir' ";

mysqli_query($koneksi,$query);

echo "
  <script>
  alert('Data Berhasil dihapus');

  window.location='../kurir.php';
  </script>
  ";
}


?>