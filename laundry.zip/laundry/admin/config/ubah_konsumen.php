<?php 
	include_once "../../database/koneksi.php";

global $koneksi;
$id_konsumen = $_POST["id_konsumen"];
$nama_konsumen = $_POST["nama"];
$hp = $_POST["hp_konsumen"];
$alamat_konsumen = $_POST["alamat"];


$update = "UPDATE t_konsumen SET nama_konsumen = '$nama_konsumen', hp = '$hp', alamat = '$alamat_konsumen' WHERE id_konsumen='$id_konsumen' ";

mysqli_query($koneksi,$update);

	echo "
	<script>
	alert('Data bagian, berhasil di update!');
	
	</script>

	";
		
 ?>