<?php
 require '../../database/koneksi.php';
if (isset($_GET["id"])) {
$kode_barang = $_GET["id"];

$query = "DELETE FROM t_barang where kode_barang = '$kode_barang' ";

mysqli_query($koneksi,$query);

echo "
  <script>
  alert('Data Berhasil dihapus');

  window.location='../barang.php';
  </script>
  ";
}


?>