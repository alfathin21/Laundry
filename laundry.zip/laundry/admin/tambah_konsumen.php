 <?php 
include "../database/koneksi.php";

  



  ?>
<!DOCTYPE html>
 <html lang="en">
<head>
	  <meta charset="utf-8">
     <meta http-equiv="X-UA-Compatible" content="IE=edge">
     <meta name="viewport" content="width=device-width, initial-scale=1">
     <meta name="description" content="">
     <meta name="author" content="">

     <title>Data Konsumen</title>

     <!-- Bootstrap Core CSS -->
     <link href="vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">

     <!-- MetisMenu CSS -->
     <link href="vendor/metisMenu/metisMenu.min.css" rel="stylesheet">

     <!-- DataTables CSS -->
     <link href="vendor/datatables-plugins/dataTables.bootstrap.css" rel="stylesheet">

     <!-- DataTables Responsive CSS -->
     <link href="vendor/datatables-responsive/dataTables.responsive.css" rel="stylesheet">

     <!-- Custom CSS -->
     <link href="dist/css/sb-admin-2.css" rel="stylesheet">

     <!-- Custom Fonts -->
     <link href="vendor/font-awesome/css/font-awesome.min.css" rel="stylesheet" type="text/css">
	<title>Tambah Data Konsumen</title>
</head>
<body>
	<div class="container">
		<form id="tambah" action="" method="POST">
        <div class="modal-body" id="modal-tambah">
         <div class="form-group">
           <label for="nama">Nama Konsumen</label>
           <input type="text" name="nama" id="nama" class="form-control">
         </div>
         <div class="form-group">
           <label for="hp_konsumen">Nomor Handphone</label>
           <input type="number" name="hp_konsumen" id="hp_konsumen" class="form-control">
         </div>
          <div class="form-group">
           <label for="alamat">Alamat</label>
          <textarea class="form-control" name="alamat" id="alamat"></textarea>
         </div>
       </div>
       <div class="modal-footer">
        <button type="submit" class="btn btn-primary" name="simpan">Simpan</button>
        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
      </div>
    </form>
	</div>

 <script src="vendor/jquery/jquery.min.js"></script>
     <script src="vendor/bootstrap/js/bootstrap.min.js"></script>
     <script src="vendor/metisMenu/metisMenu.min.js"></script>
     <script src="dist/js/sb-admin-2.js"></script>
</body>
</html>


 <?php 

  

   if (isset($_POST['simpan'])) {
    $nama_konsumen = $_POST['nama'];
    $hp = $_POST['hp_konsumen'];
    $alamat = $_POST['alamat'];


    $query = "INSERT INTO t_konsumen VALUES ('','$nama_konsumen','$hp','$alamat') ";

    mysqli_query($koneksi,$query);

   echo "<script>
  alert('Data konsumen berhasil ditambahkan');
  document.location.href = 'konsumen.php';
  </script>";

   }


 
  ?>